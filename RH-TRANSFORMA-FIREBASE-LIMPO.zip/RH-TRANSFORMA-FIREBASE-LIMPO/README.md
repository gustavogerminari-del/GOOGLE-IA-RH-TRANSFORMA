# RH Transforma — versão Firebase limpa

Esta cópia preserva as telas, componentes e regras de negócio do projeto completo e remove a infraestrutura de backend anterior.

## Stack alvo
- React + Vite
- Firebase Authentication
- Cloud Firestore
- Firebase Storage
- Firebase Hosting

## Configuração
1. Copie `.env.example` para `.env`.
2. Preencha as variáveis `VITE_FIREBASE_*` do seu projeto Firebase.
3. Execute `npm install`.
4. Execute `npm run dev`.

As integrações que dependiam de endpoints de servidor precisam ser conectadas a Cloud Functions ou outro backend seguro antes de produção.
